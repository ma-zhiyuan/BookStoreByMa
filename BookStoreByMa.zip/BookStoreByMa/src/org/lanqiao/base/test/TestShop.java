package org.lanqiao.base.test;

public class TestShop {
	
}
